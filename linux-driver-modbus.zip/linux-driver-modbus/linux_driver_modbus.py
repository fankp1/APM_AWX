#!/usr/bin/python3

# Import of required libaries
import abc
import subprocess
import json
import os
import logging
import time
import paho.mqtt.client as mqtt
from threading import Event,Lock,Timer

# Credentials of the MQTT Broker
broker_mqtt = '127.0.0.1'
port_mqtt = 1883
client_id = "RevPi"

# Callback function of the mqtt connection state
def on_connect(client_mqtt, userdata, flags, rc):
    if rc==0:
        print("Successfully connected with the local MQTT broker")
    else:
        print("Bad connection, Returned code=",rc)

# Load the mqtt configuration and connect with the local mqtt broker
client_mqtt = mqtt.Client(client_id)
client_mqtt.on_connect = on_connect
client_mqtt.loop_start()
client_mqtt.connect(broker_mqtt, port_mqtt, keepalive=60)

def main():
    while(1):
        time.sleep(1)

        try:
            output = subprocess.check_output(["./bin/read", "/dev/ttyRS485", "115200", "1"])
            if output:
                output = output.decode('ascii')
                try:
                    content = output[output.index("----------") + 11:]
                except:
                    content = 0
                if content:
                    try:
                        data = json.loads(content)
                    except:
                        data = 0
                    if data:
                        client_mqtt.publish("s2/appmodule/revpi/RevPi87158", payload=json.dumps(data))
        except Exception as e:
            print(e)
            print("Failed to read out the Cavazzi meter")


if __name__ == '__main__':
    main()
