#!/usr/bin/python3

# Import of required libaries
import abc
import subprocess
import json
import os
import logging
import time
import paho.mqtt.client as mqtt
from threading import Event,Lock,Timer
from threading import Thread
import threading
import logging

# Credentials of the MQTT Broker
broker_mqtt = '127.0.0.1'
port_mqtt = 1883
client_id = "RevPi"

threads = []
modbus_addresses = []

# Callback function of the mqtt connection state
def on_connect(client_mqtt, userdata, flags, rc):
    if rc==0:
        logging.info("Successfully connected with the local MQTT broker")
    else:
        logging.info("Bad connection, Returned code=",rc)

# Load the mqtt configuration and connect with the local mqtt broker
client_mqtt = mqtt.Client(client_id)
client_mqtt.on_connect = on_connect
client_mqtt.loop_start()
client_mqtt.connect(broker_mqtt, port_mqtt, keepalive=60)

logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)

def Readout_Meter(Port, Baudrate, Address):

    logging.info(Port)
    logging.info(Baudrate)
    logging.info(Address)

    local = threading.local()  # Create a local instance
    local.ticker = threading.Event()

    while not local.ticker.wait(3):
        try:
            output = subprocess.check_output(["./bin/read", Port, Baudrate, Address])
            if output:
                output = output.decode('ascii')
                try:
                    content = output[output.index("----------") + 11:]
                except:
                    content = 0
                if content:
                    try:
                        data = json.loads(content)
                    except:
                        data = 0
                    if data:
                        topic = "s2/appmodule/RevPi" + "/" + Address
                        client_mqtt.publish(topic, payload=json.dumps(data))
        except Exception as e:
            logging.info(e)
            logging.info("Failed to read out the Gavazzi meter with the address " + Address)


try:
    output = subprocess.check_output(["./bin/search", "/dev/ttyUSB0", "115200", "10"])

    if output:
        data = output.decode('ascii')
        data = json.loads(data, strict=False)
        logging.info("Found " + str(data['count']) + " Devices on the baudrate 115200 on the port: /dev/ttyUSB0")

        if data['count'] == 0:
            time.sleep(10)
            exit()

        for val in data["devices"]:
            modbus_addresses.append(str(val["address"]))
            thread = Thread(target=Readout_Meter, args=["/dev/ttyUSB0", "115200", str(val['address'])])
            logging.info(thread)
            time.sleep(10)

            thread.start()

except Exception as e:
    logging.info(e)

